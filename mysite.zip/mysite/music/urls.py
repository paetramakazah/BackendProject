from django.urls import path
from . views import create_instruments
app_name ='music'
urlpatterns = [
    path('', create_instruments, name='create_instruments')
]