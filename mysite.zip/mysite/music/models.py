from django.db import models

# Create your models here.
class Instruments (models.Model):
    Piano = models.CharField(null=True, blank=True, max_length=50)
    Guitar = models.CharField(null=True, blank=True, max_length=50)
    Drums = models.CharField(null=True, blank=True, max_length=50)

    def __str__(self):
        return self.Piano  