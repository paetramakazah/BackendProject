from django.shortcuts import render

# Create your views here.
from . models import Instruments
def create_person(request):
    instruments = Instruments.objects.create(
        Piano = 'black',
        Guitar = 'Brown',
        Drums = 'Brown',
    )

    context ={
        'data':instruments,
    }

    return render(request,'index.html',context)